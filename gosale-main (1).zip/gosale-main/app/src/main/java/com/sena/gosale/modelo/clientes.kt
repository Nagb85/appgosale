package com.sena.gosale.modelo

data class clientes(val nombre:String, val apellido:String, val rsocial:String )