package com.sena.gosale.modelo

data class productos(val nombre:String, val image:String, val ancho:String, val largo:String,
                     val peso:String, val lcerda:String, val espesor:String, val color:String)

